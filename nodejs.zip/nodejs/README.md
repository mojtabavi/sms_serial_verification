# TODO

- [X]  create a module for convert excel to db
- [X]  browse sheet 2 of excel and add it to db
- [X]  normalize string
- [ ]  fix get_sms_token (get token every time that want to send sms)