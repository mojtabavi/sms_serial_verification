config = {
    apiKey: "52e76b733b47c51e80a7b3a",
    secretKey: "64049e1e74dfb5885410a25d",
    LineNumber: "30004554550955",
}

module.exports = config;